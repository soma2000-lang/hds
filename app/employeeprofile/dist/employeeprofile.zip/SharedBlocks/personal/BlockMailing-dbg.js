sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";

	var BlockMailing = BlockBase.extend("employeeprofile.SharedBlocks.personal.BlockMailing", {
		metadata: {}
	});

	return BlockMailing;
});