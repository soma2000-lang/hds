sap.ui.define([],
    function () {
        'use strict';

        var constants = {
            busy : false,
            userIdValue : "",
        };

        return constants;
    });